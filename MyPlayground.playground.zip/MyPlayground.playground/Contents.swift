import Darwin
// sumar dos numeros y regresar el valor

func suma(num1: Int, num2: Int) -> Int{
    
    return num1 + num2
}

suma(num1: 3, num2: 4)

// Saber la cantidad de sugundos que tiene numero de anios seleccionado

func anoASegundos(ano: Int) -> Int {
    
    let dias = 365
    let hora = 24
    let min = 60
    let seg = 60
    
    return dias * hora * min * seg * ano
}
var anios = 500
print("La cantidad de segundos de \(anios) anios es de: \(anoASegundos(ano: 500)) segundos 😉")

// Calcular la cantidad total de píxeles que tiene una pantalla dada su altura y anchura en píxeles:

func totalPixels (alto: Int, ancho: Int) -> Int {
    
    return alto * ancho
}

print("Cantidad de Pixeles es de: \(totalPixels(alto: 170, ancho: 180))")

func albumReleased (year: Int) -> String? {
    
    switch year {
    case 1983: return "Kill 'em All"
    case 1984: return "Ride the Lightning"
    case 1986: return "Master of Puppets"
    case 1988: return "...And Justice for All"
    default: return nil
    }
}

if let album = albumReleased(year: 1986) {
print(album)
}

